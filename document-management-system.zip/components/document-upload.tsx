"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Upload, FileText, X, CheckCircle, AlertCircle, Loader2 } from "lucide-react"

interface UploadFile {
  id: string
  file: File
  progress: number
  status: "pending" | "uploading" | "processing" | "completed" | "error"
  category?: string
  extractedData?: {
    title: string
    author: string
    summary: string
  }
}

export function DocumentUpload() {
  const [files, setFiles] = useState<UploadFile[]>([])
  const [dragActive, setDragActive] = useState(false)
  const [defaultCategory, setDefaultCategory] = useState("")

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(Array.from(e.dataTransfer.files))
    }
  }, [])

  const handleFiles = (fileList: File[]) => {
    const newFiles: UploadFile[] = fileList.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      progress: 0,
      status: "pending",
      category: defaultCategory || undefined,
    }))

    setFiles((prev) => [...prev, ...newFiles])
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(Array.from(e.target.files))
    }
  }

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== id))
  }

  const updateFileCategory = (id: string, category: string) => {
    setFiles((prev) => prev.map((file) => (file.id === id ? { ...file, category } : file)))
  }

  const simulateUpload = async (fileId: string) => {
    // Simulate upload progress
    setFiles((prev) => prev.map((file) => (file.id === fileId ? { ...file, status: "uploading" } : file)))

    // Progress simulation
    for (let progress = 0; progress <= 100; progress += 10) {
      await new Promise((resolve) => setTimeout(resolve, 200))
      setFiles((prev) => prev.map((file) => (file.id === fileId ? { ...file, progress } : file)))
    }

    // Simulate processing
    setFiles((prev) =>
      prev.map((file) => (file.id === fileId ? { ...file, status: "processing", progress: 100 } : file)),
    )

    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Simulate completion with extracted data
    setFiles((prev) =>
      prev.map((file) =>
        file.id === fileId
          ? {
              ...file,
              status: "completed",
              extractedData: {
                title: file.file.name.replace(/\.[^/.]+$/, ""),
                author: "Auto-detected Author",
                summary: "This document has been successfully processed and classified using AI.",
              },
            }
          : file,
      ),
    )
  }

  const uploadAll = async () => {
    const pendingFiles = files.filter((file) => file.status === "pending")
    for (const file of pendingFiles) {
      simulateUpload(file.id)
      await new Promise((resolve) => setTimeout(resolve, 500)) // Stagger uploads
    }
  }

  const getStatusIcon = (status: UploadFile["status"]) => {
    switch (status) {
      case "pending":
        return <FileText className="h-4 w-4 text-muted-foreground" />
      case "uploading":
      case "processing":
        return <Loader2 className="h-4 w-4 animate-spin text-secondary" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-destructive" />
    }
  }

  const getStatusColor = (status: UploadFile["status"]) => {
    switch (status) {
      case "pending":
        return "bg-gray-100 text-gray-800"
      case "uploading":
        return "bg-blue-100 text-blue-800"
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "error":
        return "bg-red-100 text-red-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card className="border-0 shadow-sm bg-card/50">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Upload Documents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Default Category Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="default-category">Default Category</Label>
                <Select value={defaultCategory} onValueChange={setDefaultCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select default category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Finance">Finance</SelectItem>
                    <SelectItem value="HR">HR</SelectItem>
                    <SelectItem value="Legal">Legal</SelectItem>
                    <SelectItem value="Technical Reports">Technical Reports</SelectItem>
                    <SelectItem value="Contracts">Contracts</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Drag and Drop Area */}
            <div
              className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive ? "border-secondary bg-secondary/10" : "border-border hover:border-secondary/50"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <div className="space-y-2">
                <p className="text-lg font-medium">Drop files here or click to browse</p>
                <p className="text-sm text-muted-foreground">Supports PDF, DOCX, TXT files up to 10MB each</p>
              </div>
              <input
                type="file"
                multiple
                accept=".pdf,.docx,.txt"
                onChange={handleFileInput}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>

            {/* Upload All Button */}
            {files.length > 0 && (
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  {files.length} file{files.length !== 1 ? "s" : ""} ready to upload
                </p>
                <Button onClick={uploadAll} className="bg-secondary hover:bg-secondary/90">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload All Files
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* File List */}
      {files.length > 0 && (
        <Card className="border-0 shadow-sm bg-card/50">
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Upload Queue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {files.map((uploadFile) => (
                <div key={uploadFile.id} className="border rounded-lg p-4 space-y-3 bg-background/50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(uploadFile.status)}
                      <div>
                        <p className="font-medium text-sm">{uploadFile.file.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(uploadFile.file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(uploadFile.status)}>{uploadFile.status}</Badge>
                      {uploadFile.status === "pending" && (
                        <Button variant="ghost" size="sm" onClick={() => removeFile(uploadFile.id)}>
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Progress Bar */}
                  {(uploadFile.status === "uploading" || uploadFile.status === "processing") && (
                    <div className="space-y-2">
                      <Progress value={uploadFile.progress} className="w-full" />
                      <p className="text-xs text-muted-foreground">
                        {uploadFile.status === "uploading"
                          ? `Uploading... ${uploadFile.progress}%`
                          : "Processing with AI..."}
                      </p>
                    </div>
                  )}

                  {/* Category Selection */}
                  {uploadFile.status === "pending" && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Category</Label>
                        <Select
                          value={uploadFile.category || ""}
                          onValueChange={(value) => updateFileCategory(uploadFile.id, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Finance">Finance</SelectItem>
                            <SelectItem value="HR">HR</SelectItem>
                            <SelectItem value="Legal">Legal</SelectItem>
                            <SelectItem value="Technical Reports">Technical Reports</SelectItem>
                            <SelectItem value="Contracts">Contracts</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  {/* Extracted Data */}
                  {uploadFile.status === "completed" && uploadFile.extractedData && (
                    <div className="bg-muted/50 rounded-lg p-3 space-y-2">
                      <h4 className="font-medium text-sm">Extracted Information</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Title:</span> {uploadFile.extractedData.title}
                        </div>
                        <div>
                          <span className="font-medium">Author:</span> {uploadFile.extractedData.author}
                        </div>
                      </div>
                      <div className="text-sm">
                        <span className="font-medium">Summary:</span> {uploadFile.extractedData.summary}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
