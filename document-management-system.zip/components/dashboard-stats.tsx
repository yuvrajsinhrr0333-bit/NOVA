import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Upload, Search, Users } from "lucide-react"

const stats = [
  {
    title: "Total Documents",
    value: "2,847",
    change: "+12%",
    changeType: "positive" as const,
    icon: FileText,
    description: "Documents in system",
  },
  {
    title: "Uploaded Today",
    value: "23",
    change: "+5%",
    changeType: "positive" as const,
    icon: Upload,
    description: "New uploads today",
  },
  {
    title: "Search Queries",
    value: "1,429",
    change: "+8%",
    changeType: "positive" as const,
    icon: Search,
    description: "Searches this week",
  },
  {
    title: "Active Users",
    value: "89",
    change: "+2%",
    changeType: "positive" as const,
    icon: Users,
    description: "Users this month",
  },
]

export function DashboardStats() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.title} className="border-0 shadow-sm bg-card/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
              <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-card-foreground">{stat.value}</div>
              <div className="flex items-center space-x-2 text-xs">
                <span className={`font-medium ${stat.changeType === "positive" ? "text-green-600" : "text-red-600"}`}>
                  {stat.change}
                </span>
                <span className="text-muted-foreground">from last month</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
