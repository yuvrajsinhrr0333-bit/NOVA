"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Download, Eye, Calendar, User, Star, Clock } from "lucide-react"

// Mock search results with relevance scores
const searchResults = [
  {
    id: 1,
    title: "Q4 Financial Report 2024",
    category: "Finance",
    author: "John Smith",
    uploadDate: "2024-01-15",
    size: "2.4 MB",
    relevanceScore: 95,
    summary:
      "Comprehensive financial analysis for Q4 2024 including revenue growth, expense management, and profit margins. Key highlights include 15% revenue increase and cost optimization strategies.",
    matchedTerms: ["financial", "Q4", "revenue", "profit"],
    lastAccessed: "2 hours ago",
  },
  {
    id: 2,
    title: "Employee Performance Review Guidelines",
    category: "HR",
    author: "Sarah Johnson",
    uploadDate: "2024-01-14",
    size: "1.8 MB",
    relevanceScore: 87,
    summary:
      "Updated guidelines for conducting employee performance reviews, including new evaluation criteria and feedback mechanisms. Covers goal setting and development planning.",
    matchedTerms: ["employee", "performance", "review"],
    lastAccessed: "1 day ago",
  },
  {
    id: 3,
    title: "Software License Agreement - Microsoft Office",
    category: "Legal",
    author: "Mike Davis",
    uploadDate: "2024-01-13",
    size: "856 KB",
    relevanceScore: 78,
    summary:
      "Legal agreement for Microsoft Office software licensing, including terms of use, restrictions, and compliance requirements for enterprise deployment.",
    matchedTerms: ["software", "license", "agreement"],
    lastAccessed: "3 days ago",
  },
  {
    id: 4,
    title: "Cloud Infrastructure Technical Specification",
    category: "Technical Reports",
    author: "Emily Chen",
    uploadDate: "2024-01-12",
    size: "3.2 MB",
    relevanceScore: 72,
    summary:
      "Detailed technical specifications for cloud infrastructure migration, including architecture diagrams, security protocols, and implementation timeline.",
    matchedTerms: ["cloud", "infrastructure", "technical"],
    lastAccessed: "5 days ago",
  },
  {
    id: 5,
    title: "Vendor Service Contract - ABC Corporation",
    category: "Contracts",
    author: "Robert Wilson",
    uploadDate: "2024-01-11",
    size: "1.2 MB",
    relevanceScore: 65,
    summary:
      "Service contract with ABC Corporation for IT support services, including SLA requirements, pricing structure, and termination clauses.",
    matchedTerms: ["vendor", "contract", "service"],
    lastAccessed: "1 week ago",
  },
]

const categoryColors = {
  Finance: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
  HR: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
  Legal: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
  "Technical Reports": "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300",
  Contracts: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300",
}

export function SearchResults() {
  const [sortBy, setSortBy] = useState("relevance")
  const [viewMode, setViewMode] = useState("detailed")

  const sortedResults = [...searchResults].sort((a, b) => {
    switch (sortBy) {
      case "relevance":
        return b.relevanceScore - a.relevanceScore
      case "date":
        return new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()
      case "title":
        return a.title.localeCompare(b.title)
      default:
        return 0
    }
  })

  const getRelevanceColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            Search Results ({searchResults.length} documents found)
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="date">Date</SelectItem>
                <SelectItem value="title">Title</SelectItem>
              </SelectContent>
            </Select>
            <Select value={viewMode} onValueChange={setViewMode}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="detailed">Detailed</SelectItem>
                <SelectItem value="compact">Compact</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sortedResults.map((result) => (
            <div
              key={result.id}
              className="border rounded-lg p-4 space-y-3 bg-background/50 hover:bg-background/80 transition-colors"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <FileText className="h-5 w-5 text-muted-foreground mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="font-semibold text-lg hover:text-secondary cursor-pointer">{result.title}</h3>
                      <div className="flex items-center space-x-1">
                        <Star className={`h-4 w-4 ${getRelevanceColor(result.relevanceScore)}`} />
                        <span className={`text-sm font-medium ${getRelevanceColor(result.relevanceScore)}`}>
                          {result.relevanceScore}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <User className="h-3 w-3" />
                        <span>{result.author}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-3 w-3" />
                        <span>{result.uploadDate}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>Last accessed {result.lastAccessed}</span>
                      </div>
                      <span>{result.size}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary" className={categoryColors[result.category as keyof typeof categoryColors]}>
                    {result.category}
                  </Badge>
                  <Button variant="ghost" size="sm">
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Summary */}
              {viewMode === "detailed" && (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground leading-relaxed">{result.summary}</p>

                  {/* Matched Terms */}
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-medium text-muted-foreground">Matched terms:</span>
                    <div className="flex flex-wrap gap-1">
                      {result.matchedTerms.map((term) => (
                        <Badge key={term} variant="outline" className="text-xs bg-secondary/10 text-secondary">
                          {term}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-6 pt-4 border-t">
          <p className="text-sm text-muted-foreground">Showing 1-5 of 5 results</p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" disabled>
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
