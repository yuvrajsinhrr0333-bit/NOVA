"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Filter, X } from "lucide-react"

const categories = [
  { id: "finance", label: "Finance", count: 234 },
  { id: "hr", label: "HR", count: 156 },
  { id: "legal", label: "Legal", count: 89 },
  { id: "technical", label: "Technical Reports", count: 67 },
  { id: "contracts", label: "Contracts", count: 45 },
]

const authors = [
  { id: "john", label: "John Smith", count: 45 },
  { id: "sarah", label: "Sarah Johnson", count: 38 },
  { id: "mike", label: "Mike Davis", count: 32 },
  { id: "emily", label: "Emily Chen", count: 28 },
  { id: "robert", label: "Robert Wilson", count: 24 },
]

const fileTypes = [
  { id: "pdf", label: "PDF", count: 345 },
  { id: "docx", label: "DOCX", count: 234 },
  { id: "txt", label: "TXT", count: 123 },
]

const fileSizes = [
  { id: "small", label: "< 1 MB", count: 234 },
  { id: "medium", label: "1-5 MB", count: 345 },
  { id: "large", label: "> 5 MB", count: 123 },
]

export function SearchFilters() {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedAuthors, setSelectedAuthors] = useState<string[]>([])
  const [selectedFileTypes, setSelectedFileTypes] = useState<string[]>([])
  const [selectedFileSizes, setSelectedFileSizes] = useState<string[]>([])

  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, categoryId])
    } else {
      setSelectedCategories(selectedCategories.filter((id) => id !== categoryId))
    }
  }

  const handleAuthorChange = (authorId: string, checked: boolean) => {
    if (checked) {
      setSelectedAuthors([...selectedAuthors, authorId])
    } else {
      setSelectedAuthors(selectedAuthors.filter((id) => id !== authorId))
    }
  }

  const handleFileTypeChange = (typeId: string, checked: boolean) => {
    if (checked) {
      setSelectedFileTypes([...selectedFileTypes, typeId])
    } else {
      setSelectedFileTypes(selectedFileTypes.filter((id) => id !== typeId))
    }
  }

  const handleFileSizeChange = (sizeId: string, checked: boolean) => {
    if (checked) {
      setSelectedFileSizes([...selectedFileSizes, sizeId])
    } else {
      setSelectedFileSizes(selectedFileSizes.filter((id) => id !== sizeId))
    }
  }

  const clearAllFilters = () => {
    setSelectedCategories([])
    setSelectedAuthors([])
    setSelectedFileTypes([])
    setSelectedFileSizes([])
  }

  const totalFilters =
    selectedCategories.length + selectedAuthors.length + selectedFileTypes.length + selectedFileSizes.length

  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center">
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </CardTitle>
          {totalFilters > 0 && (
            <Badge variant="secondary" className="bg-secondary/20">
              {totalFilters}
            </Badge>
          )}
        </div>
        {totalFilters > 0 && (
          <Button variant="ghost" size="sm" onClick={clearAllFilters} className="w-full justify-start p-0 h-auto">
            <X className="mr-2 h-3 w-3" />
            Clear all filters
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Categories */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Categories</h4>
          <div className="space-y-2">
            {categories.map((category) => (
              <div key={category.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={category.id}
                    checked={selectedCategories.includes(category.id)}
                    onCheckedChange={(checked) => handleCategoryChange(category.id, checked as boolean)}
                  />
                  <Label htmlFor={category.id} className="text-sm font-normal cursor-pointer">
                    {category.label}
                  </Label>
                </div>
                <span className="text-xs text-muted-foreground">{category.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Authors */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">Authors</h4>
          <div className="space-y-2">
            {authors.map((author) => (
              <div key={author.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={author.id}
                    checked={selectedAuthors.includes(author.id)}
                    onCheckedChange={(checked) => handleAuthorChange(author.id, checked as boolean)}
                  />
                  <Label htmlFor={author.id} className="text-sm font-normal cursor-pointer">
                    {author.label}
                  </Label>
                </div>
                <span className="text-xs text-muted-foreground">{author.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* File Types */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">File Types</h4>
          <div className="space-y-2">
            {fileTypes.map((type) => (
              <div key={type.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={type.id}
                    checked={selectedFileTypes.includes(type.id)}
                    onCheckedChange={(checked) => handleFileTypeChange(type.id, checked as boolean)}
                  />
                  <Label htmlFor={type.id} className="text-sm font-normal cursor-pointer">
                    {type.label}
                  </Label>
                </div>
                <span className="text-xs text-muted-foreground">{type.count}</span>
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* File Sizes */}
        <div className="space-y-3">
          <h4 className="font-medium text-sm">File Size</h4>
          <div className="space-y-2">
            {fileSizes.map((size) => (
              <div key={size.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={size.id}
                    checked={selectedFileSizes.includes(size.id)}
                    onCheckedChange={(checked) => handleFileSizeChange(size.id, checked as boolean)}
                  />
                  <Label htmlFor={size.id} className="text-sm font-normal cursor-pointer">
                    {size.label}
                  </Label>
                </div>
                <span className="text-xs text-muted-foreground">{size.count}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
