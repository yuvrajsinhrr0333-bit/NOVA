"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Search, FileText, Filter } from "lucide-react"

export function QuickActions() {
  const handleUploadClick = () => {
    window.location.href = "/upload"
  }

  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-3">
          <Button className="bg-secondary hover:bg-secondary/90 text-secondary-foreground" onClick={handleUploadClick}>
            <Upload className="mr-2 h-4 w-4" />
            Upload Document
          </Button>
          <Button variant="outline">
            <Search className="mr-2 h-4 w-4" />
            Advanced Search
          </Button>
          <Button variant="outline">
            <FileText className="mr-2 h-4 w-4" />
            Create Report
          </Button>
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" />
            Manage Filters
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
