"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { FileText, Download, Eye, Calendar, User, Filter } from "lucide-react"

// Mock data
const documents = [
  {
    id: 1,
    title: "Q4 Financial Report 2024",
    category: "Finance",
    author: "John Smith",
    uploadDate: "2024-01-15",
    size: "2.4 MB",
    status: "Processed",
  },
  {
    id: 2,
    title: "Employee Handbook Update",
    category: "HR",
    author: "Sarah Johnson",
    uploadDate: "2024-01-14",
    size: "1.8 MB",
    status: "Processing",
  },
  {
    id: 3,
    title: "Software License Agreement",
    category: "Legal",
    author: "Mike Davis",
    uploadDate: "2024-01-13",
    size: "856 KB",
    status: "Processed",
  },
  {
    id: 4,
    title: "Technical Architecture Document",
    category: "Technical Reports",
    author: "Emily Chen",
    uploadDate: "2024-01-12",
    size: "3.2 MB",
    status: "Processed",
  },
  {
    id: 5,
    title: "Vendor Contract - ABC Corp",
    category: "Contracts",
    author: "Robert Wilson",
    uploadDate: "2024-01-11",
    size: "1.2 MB",
    status: "Processed",
  },
]

const categoryColors = {
  Finance: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
  HR: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
  Legal: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
  "Technical Reports": "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300",
  Contracts: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300",
}

export function DocumentList() {
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [authorFilter, setAuthorFilter] = useState("all")

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.author.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || doc.category === categoryFilter
    const matchesAuthor = authorFilter === "all" || doc.author === authorFilter

    return matchesSearch && matchesCategory && matchesAuthor
  })

  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Recent Documents</CardTitle>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Advanced Filters
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mt-4">
          <div className="flex-1">
            <Input
              placeholder="Search documents or authors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="Finance">Finance</SelectItem>
              <SelectItem value="HR">HR</SelectItem>
              <SelectItem value="Legal">Legal</SelectItem>
              <SelectItem value="Technical Reports">Technical Reports</SelectItem>
              <SelectItem value="Contracts">Contracts</SelectItem>
            </SelectContent>
          </Select>
          <Select value={authorFilter} onValueChange={setAuthorFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Author" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Authors</SelectItem>
              <SelectItem value="John Smith">John Smith</SelectItem>
              <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
              <SelectItem value="Mike Davis">Mike Davis</SelectItem>
              <SelectItem value="Emily Chen">Emily Chen</SelectItem>
              <SelectItem value="Robert Wilson">Robert Wilson</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>

      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Document</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Author</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDocuments.map((doc) => (
                <TableRow key={doc.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <div className="font-medium">{doc.title}</div>
                        <div className="text-sm text-muted-foreground">{doc.size}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={categoryColors[doc.category as keyof typeof categoryColors]}>
                      {doc.category}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <User className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm">{doc.author}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Calendar className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm">{doc.uploadDate}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={doc.status === "Processed" ? "default" : "secondary"}
                      className={doc.status === "Processed" ? "bg-green-100 text-green-800" : ""}
                    >
                      {doc.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {filteredDocuments.length === 0 && (
          <div className="text-center py-8">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No documents found matching your criteria.</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
