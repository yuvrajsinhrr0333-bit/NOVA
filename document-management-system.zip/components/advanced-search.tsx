"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Search, X, Sparkles, Calendar, User, Tag } from "lucide-react"

export function AdvancedSearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [semanticQuery, setSemanticQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all-categories")
  const [selectedAuthor, setSelectedAuthor] = useState("all-authors")
  const [dateRange, setDateRange] = useState("any-time")
  const [searchTags, setSearchTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")

  const addTag = () => {
    if (newTag.trim() && !searchTags.includes(newTag.trim())) {
      setSearchTags([...searchTags, newTag.trim()])
      setNewTag("")
    }
  }

  const removeTag = (tag: string) => {
    setSearchTags(searchTags.filter((t) => t !== tag))
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement search logic
    console.log("Searching with:", {
      searchQuery,
      semanticQuery,
      selectedCategory,
      selectedAuthor,
      dateRange,
      searchTags,
    })
  }

  const clearFilters = () => {
    setSearchQuery("")
    setSemanticQuery("")
    setSelectedCategory("all-categories")
    setSelectedAuthor("all-authors")
    setDateRange("any-time")
    setSearchTags([])
    setNewTag("")
  }

  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <CardTitle className="text-lg font-semibold flex items-center">
          <Search className="mr-2 h-5 w-5" />
          Advanced Search
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSearch} className="space-y-6">
          {/* Basic Search */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search-query">Keyword Search</Label>
              <Input
                id="search-query"
                placeholder="Enter keywords, titles, or phrases..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="semantic-query" className="flex items-center">
                <Sparkles className="mr-1 h-4 w-4 text-secondary" />
                Semantic Search
              </Label>
              <Textarea
                id="semantic-query"
                placeholder="Describe what you're looking for in natural language..."
                value={semanticQuery}
                onChange={(e) => setSemanticQuery(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center">
                <Tag className="mr-1 h-4 w-4" />
                Category
              </Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-categories">All Categories</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                  <SelectItem value="HR">HR</SelectItem>
                  <SelectItem value="Legal">Legal</SelectItem>
                  <SelectItem value="Technical Reports">Technical Reports</SelectItem>
                  <SelectItem value="Contracts">Contracts</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center">
                <User className="mr-1 h-4 w-4" />
                Author
              </Label>
              <Select value={selectedAuthor} onValueChange={setSelectedAuthor}>
                <SelectTrigger>
                  <SelectValue placeholder="All authors" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-authors">All Authors</SelectItem>
                  <SelectItem value="John Smith">John Smith</SelectItem>
                  <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                  <SelectItem value="Mike Davis">Mike Davis</SelectItem>
                  <SelectItem value="Emily Chen">Emily Chen</SelectItem>
                  <SelectItem value="Robert Wilson">Robert Wilson</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center">
                <Calendar className="mr-1 h-4 w-4" />
                Date Range
              </Label>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger>
                  <SelectValue placeholder="Any time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any-time">Any Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="quarter">This Quarter</SelectItem>
                  <SelectItem value="year">This Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label>Search Tags</Label>
            <div className="flex flex-wrap gap-2 mb-2">
              {searchTags.map((tag) => (
                <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                  {tag}
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="h-auto p-0 hover:bg-transparent"
                    onClick={() => removeTag(tag)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              ))}
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Add search tag..."
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add Tag
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between">
            <Button type="button" variant="outline" onClick={clearFilters}>
              Clear All Filters
            </Button>
            <div className="flex gap-2">
              <Button type="submit" className="bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                <Search className="mr-2 h-4 w-4" />
                Search Documents
              </Button>
            </div>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
