import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileText, Clock, CheckCircle, AlertCircle } from "lucide-react"

const recentUploads = [
  {
    id: 1,
    name: "Q4 Financial Report.pdf",
    status: "completed",
    time: "2 minutes ago",
    category: "Finance",
    size: "2.4 MB",
  },
  {
    id: 2,
    name: "Employee Handbook.docx",
    status: "processing",
    time: "5 minutes ago",
    category: "HR",
    size: "1.8 MB",
  },
  {
    id: 3,
    name: "License Agreement.pdf",
    status: "completed",
    time: "1 hour ago",
    category: "Legal",
    size: "856 KB",
  },
  {
    id: 4,
    name: "Tech Spec.docx",
    status: "error",
    time: "2 hours ago",
    category: "Technical Reports",
    size: "3.2 MB",
  },
  {
    id: 5,
    name: "Vendor Contract.pdf",
    status: "completed",
    time: "3 hours ago",
    category: "Contracts",
    size: "1.2 MB",
  },
]

const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle className="h-4 w-4 text-green-600" />
    case "processing":
      return <Clock className="h-4 w-4 text-yellow-600" />
    case "error":
      return <AlertCircle className="h-4 w-4 text-destructive" />
    default:
      return <FileText className="h-4 w-4 text-muted-foreground" />
  }
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "completed":
      return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
    case "processing":
      return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
    case "error":
      return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
    default:
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
  }
}

export function UploadHistory() {
  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Recent Uploads</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentUploads.map((upload) => (
            <div key={upload.id} className="flex items-start space-x-3 p-3 rounded-lg bg-background/50">
              <div className="flex-shrink-0 mt-1">{getStatusIcon(upload.status)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium truncate">{upload.name}</p>
                  <Badge variant="secondary" className={`text-xs ${getStatusColor(upload.status)}`}>
                    {upload.status}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{upload.category}</span>
                  <span>{upload.size}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{upload.time}</p>
                {upload.status === "error" && (
                  <Button variant="outline" size="sm" className="mt-2 h-6 text-xs bg-transparent">
                    Retry Upload
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
