import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Upload, Eye, Download, Search } from "lucide-react"

const activities = [
  {
    id: 1,
    user: "John Smith",
    action: "uploaded",
    target: "Q4 Financial Report",
    time: "2 minutes ago",
    type: "upload",
    icon: Upload,
  },
  {
    id: 2,
    user: "Sarah Johnson",
    action: "viewed",
    target: "Employee Handbook",
    time: "15 minutes ago",
    type: "view",
    icon: Eye,
  },
  {
    id: 3,
    user: "Mike Davis",
    action: "downloaded",
    target: "License Agreement",
    time: "1 hour ago",
    type: "download",
    icon: Download,
  },
  {
    id: 4,
    user: "Emily Chen",
    action: "searched for",
    target: '"technical documentation"',
    time: "2 hours ago",
    type: "search",
    icon: Search,
  },
  {
    id: 5,
    user: "Robert Wilson",
    action: "uploaded",
    target: "Vendor Contract",
    time: "3 hours ago",
    type: "upload",
    icon: Upload,
  },
]

const getActivityColor = (type: string) => {
  switch (type) {
    case "upload":
      return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
    case "view":
      return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
    case "download":
      return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
    case "search":
      return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
    default:
      return "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
  }
}

export function RecentActivity() {
  return (
    <Card className="border-0 shadow-sm bg-card/50">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => {
            const Icon = activity.icon
            return (
              <div key={activity.id} className="flex items-start space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-muted text-muted-foreground text-xs">
                    {activity.user
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center space-x-2">
                    <Icon className="h-3 w-3 text-muted-foreground" />
                    <Badge variant="secondary" className={`text-xs ${getActivityColor(activity.type)}`}>
                      {activity.type}
                    </Badge>
                  </div>
                  <p className="text-sm">
                    <span className="font-medium">{activity.user}</span> {activity.action}{" "}
                    <span className="font-medium">{activity.target}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
