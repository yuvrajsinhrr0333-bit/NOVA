import { LoginForm } from "@/components/login-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background flex items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-md animate-slide-up">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">DocuMind AI</h1>
          <p className="text-muted-foreground">Intelligent Document Management System</p>
        </div>

        <Card className="shadow-xl border-0 bg-card/90 backdrop-blur-sm hover-card">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-xl text-card-foreground">Welcome Back</CardTitle>
            <CardDescription>Sign in to access your document workspace</CardDescription>
          </CardHeader>
          <CardContent>
            <LoginForm />
          </CardContent>
        </Card>

        <div className="mt-6 text-center text-sm text-muted-foreground animate-slide-up stagger-1">
          <p>Secure • Intelligent • Efficient</p>
        </div>
      </div>
    </div>
  )
}
