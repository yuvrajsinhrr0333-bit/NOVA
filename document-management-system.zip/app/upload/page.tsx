import { DashboardHeader } from "@/components/dashboard-header"
import { DocumentUpload } from "@/components/document-upload"
import { UploadHistory } from "@/components/upload-history"

export default function UploadPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Upload Documents</h1>
            <p className="text-muted-foreground">Upload and process your documents with AI-powered classification</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Upload Form - Takes up 2 columns */}
          <div className="lg:col-span-2">
            <DocumentUpload />
          </div>

          {/* Upload History Sidebar */}
          <div className="lg:col-span-1">
            <UploadHistory />
          </div>
        </div>
      </main>
    </div>
  )
}
