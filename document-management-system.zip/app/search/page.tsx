import { DashboardHeader } from "@/components/dashboard-header"
import { AdvancedSearch } from "@/components/advanced-search"
import { SearchResults } from "@/components/search-results"
import { SearchFilters } from "@/components/search-filters"

export default function SearchPage() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Advanced Search</h1>
            <p className="text-muted-foreground">Find documents using AI-powered semantic search</p>
          </div>
        </div>

        {/* Advanced Search Form */}
        <AdvancedSearch />

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Search Filters Sidebar */}
          <div className="lg:col-span-1">
            <SearchFilters />
          </div>

          {/* Search Results */}
          <div className="lg:col-span-3">
            <SearchResults />
          </div>
        </div>
      </main>
    </div>
  )
}
